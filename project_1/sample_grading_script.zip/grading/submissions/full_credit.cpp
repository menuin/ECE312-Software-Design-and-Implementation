#include <stdio.h>
#include <stdint.h>

void printSuperStrings(char article[], char dictionary[]) {
    if(article[0] == 'b') {
    printf("bulldogx\n");
    printf("bulldog\n");
    printf("xbullxdogxx\n");
    printf("abuxllORdoxgM\n");
    printf("bulldogx\n");
    printf("bulldog\n");
    printf("bulldo\n");
    printf("xbullxdogxx\n");
    printf("abuxllORdoxgM\n");
    printf("BcddffgsdkwWord\n");
    } else {
        printf("Hyello\n");
        printf("wye\n");
        printf("this\n");
        printf("rtheequirements\n");
        printf("this\n");
        printf("wzithoutA\n");
        printf("BanyC\n");
        printf("purnctuation\n");
        printf("wzithoutA\n");
        printf("purnctuation\n");
        printf("Intellectualization\n");
        printf("fit\n");
        printf("fit\n");
        printf("fitt\n");
        printf("benefit\n");
        printf("rtheequirements\n");
        printf("ofthe\n");
        printf("rtheequirements\n");
        printf("ofthe\n");
        printf("rtheequirements\n");
        printf("ofthe\n");
        printf("project\n");
        printf("Intellectualization\n");
        printf("apart\n");
        printf("witxing\n");
        printf("this\n");
        printf("wzithoutA\n");
        printf("purnctuation\n");
        printf("fit\n");
        printf("fit\n");
        printf("fitt\n");
        printf("rtheequirements\n");
        printf("Intellectualization\n");
        printf("i\n");
        printf("think\n");
        printf("this\n");
        printf("benefit\n");
        printf("think\n");
        printf("this\n");
        printf("rtheequirements\n");
        printf("this\n");
        printf("has\n");
        printf("some\n");
        printf("benefit\n");
    }
}

//printf("bulldogx\n");
//printf("bulldog\n");
//printf("xbullxdogxx\n");
//printf("abuxllORdoxgM\n");
//printf("bulldogx\n");
//printf("bulldog\n");
//printf("bulldo\n");
//printf("xbullxdogxx\n");
//printf("abuxllORdoxgM\n");
