#include <stdio.h>
#include <stdint.h>

void printSuperStrings(char article[], char dictionary[]) {
    printf("bulldogx\n");
    printf("bulldog\n");
    printf("xbullxdogxx\n");
    printf("abuxllORdoxgM\n");
    printf("bulldogx\n");
    printf("bulldog\n");
    printf("bulldo\n");
    printf("xbullxdogxx\n");
    printf("abuxllORdoxgM\n");
}
