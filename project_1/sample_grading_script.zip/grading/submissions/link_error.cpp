#include <stdio.h>
#include <stdint.h>

void printSuperstring(char article[], char dictionary[]) {
}

int main(int argc, char *argv[]) {
    printf("Hello World!\n");
    return 0;
}
